<!-- 
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Travel Agency</title>
    <!-- <link rel="stylesheet" href="reset.css"> 
    <link rel="stylesheet" href="style.css">
    


</head>

<body> -->
    <header>
        <nav class="navbar">
            <img id="logo" src="images/logo.jpg" alt="Sorry Image is not available">
            <span>WELCOME TO THE <br>TRAVEL EXPERT </span>
            <?php
             date_default_timezone_set('Canada/Mountain');
             $today = date("H:ia");  
             echo "The time is " .$today;

             function Greeting($time){
                    if ($time>"0:00" and $time <"13:00"){
                        echo "Good Morning";
                    } else {
                        echo "Good afternoon";

                    }
                }
                Greeting($today)
            ?>
            <ul class="nav button">
                <li class="push"><a href="index.php">HOME</a></li>
                <li class="push"><a href="register.html">REGISTER</a></li>
                <li class="push"><a href="contact.html">CONTACT</a></li>
                <li class="push"><a href="links.php">Links</a></li>
                <li class="push"><a href="log_in.php">Log IN </a></li>
            </ul>

        </nav>
    </header>