<?php

// if (isset($_POST['login'])){
    $dbServername="localhost";
      $dbUsername="root";
      $dbPassword="";
      $dbName="travelexperts";
      $link = mysqli_connect( $dbServername,$dbUsername, $dbPassword,$dbName) or die("Connection Error: " . mysqli_connect_error());
      $user =  $_POST['userID'];    
      $Password = trim($_POST['Password']) ; 
    echo $user;
    echo $Password;

   
   $filename = "validUser.txt";
   $filehandle = fopen($filename, "r");
   $input = fread($filehandle, filesize( $filename));
   fclose($filehandle);
   $lines = file($filename);
   $userlist=array();
   foreach ($lines as $line)
   {    
    $dbuser=explode(',',$line); 
    $userlist[$dbuser[0]]= isset($dbuser[1]) ? $dbuser[1]: null;    
   }; 
  
   foreach($userlist as $dbuser=>$pass){
 
     if ($Password==trim($pass)){
      $_SESSION["loggedin"] = $user;
      header("Location: index.php");
     } 
     else{
      header('location:log_in.php');       
     }
   }
   
   ?>