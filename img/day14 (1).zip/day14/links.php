<html>
	<head>
		 <title>Links</title>
	</head>
	<body>
		 <?php
			/* The following code will create three links using <a> */
			include_once("header.php");
		
			
			
            echo "<h1><a href=index.php>Index</a><h1><br>";

			// $links = array("page1.php","page2.php","page3.php","page4.php","page5.php","page6.php");
			// echo "<table style ='border:1px solid black'>";
			// echo "<tr><th style ='border:1px solid black'>Page Number </th><th>Page URL</th></tr>";
			// $i=1;
			// foreach($links as $link)
			// {
			// echo "<tr>";
			// echo "<td style ='border:1px solid black'>".$i."</td>";	
			// echo "<td style ='border:1px solid black'><a href=\"$link\">$link</a></td>";					
			// echo "</tr>";
			// $i++;
			// }			
			// echo"</table><br>";
			include_once("variables.php");
			
			echo "<table style ='border:1px solid black'>";
			echo "<tr><th style ='border:1px solid black'>Page Number</th><th>Page URL</th></tr>";

			foreach($links as $url=>$description)
			{
			echo "<tr>";
			echo "<td style ='border:1px solid black'>".$description."</td>";	
			echo "<td style ='border:1px solid black'><a href=\"$url\">$url</a></td>";		
			echo "</tr>";
			}			
			echo"</table>";
			
			include_once("footer.php");
			

		?> 
	</body>
</html>
