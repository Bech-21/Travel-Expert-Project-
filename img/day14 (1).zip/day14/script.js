

function focusFunc(TextId) {
    {
        var fnameP = document.getElementById(TextId + "T");
        fnameP.style.color = "black";
        fnameP.innerHTML = "Please Enter " + TextId + "";
    }
}
function blurFunc(TextId) {
    {
        var fnameP = document.getElementById(TextId + "T");
        fnameP.innerHTML = "";
    }
}

var fname = document.getElementById("First Name");
lname = document.getElementById("Last Name");
address = document.getElementById("Address");
City = document.getElementById("City");
var register = document.getElementById("register");
var error = document.getElementById("error");

// validation function for form 
function validation() {
  
    if (fname.value == "" || lname.value=="" || address.value==""|| City=="") {
        error.innerHTML = "Please Enter All Required Info"       
        return false;
    } else {       
        return true;
    }
}

