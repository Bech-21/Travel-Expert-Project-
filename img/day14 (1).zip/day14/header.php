<?php 
session_start()
?>

 
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Travel Agency</title>
    <!-- <link rel="stylesheet" href="reset.css">  -->
    <link rel="stylesheet" href="style.css">
    


</head>

<body>
    <header>
        <nav class="navbar">
            <div class="logobar">
                <div>
                <img id="logo" src="images/logo.jpg" alt="Sorry Image is not available">
                <span>WELCOME TO THE <br>TRAVEL EXPERT </span>
                </div>
                <div class="time">
                    <?php
                        date_default_timezone_set('Canada/Mountain');
                        $today = date("H:ia");  
                        echo $today;

                        function Greeting($time){
                                if ($time>"0:00" and $time <"13:00"){
                                    echo " GOOD MORNING CALGARY";
                                } else {
                                    echo "GOOD AFTERNOON CALGARY";
                                }
                            }
                            Greeting($today)                
                    ?>
                </div>            
            </div>
           <div class="navbtn">
               <div class="navlink">                   
                    <ul class="nav button">
                        <li class="push"><a href="index.php">Home</a></li>
                        <li class="push"><a href="register.php">Register</a></li>
                        <li class="push"><a href="contact.php">Contact</a></li>
                        <li class="push"><a href="links.php">Links</a></li>
                        <li class="push"><a href="log_in.php">Login </a></li>
                    </ul>
               </div>
                <div class="login">
                    <?php   
                        if (isset($_SESSION["loggedin"])){
                            echo sprintf('<p class = "logging-status">User: %s login!</p>',$_SESSION["loggedin"]);
                        }
                        else{
                            echo '<p class="logging-status"> you are logged out!</p>' ;
                                }
                    ?>
                </div>
           </div>           
        </nav>
    </header>