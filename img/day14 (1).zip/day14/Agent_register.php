<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register</title>
    <!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">
    <script text="text/javascript" src="script.js"></script>
</head>


<body>
<?php
include_once("header.php");
?>

    <form method="POST" action="agent_form.php">
        <div class="container">
            <h2 class="register">Register</h2>
            <p>Please fill in this form to create an account.</p>
            <hr>
            <div class="name_wrapper">
                <div class="firstname">
                    <label for="firstname"><b>First Name:</b></label>
                    <input id="First Name" type="text" name="firstname" onfocus="focusFunc(this.id)"
                        onblur="blurFunc(this.id)">
                    <p id="First NameT" style="display: inline; margin-left: 30px;"></p><br />
                </div>
                <div class="midllename">
                    <label for="middlename"><b>Middle Name:</b></label>
                    <input id="Middle Name" type="text" name="middlename" onfocus="focusFunc(this.id)"
                        onblur="blurFunc(this.id)">
                    <p id="Middle NameT" style="display: inline; margin-left: 30px;"></p><br />
                </div>
                <div class="lastname">
                    <label for="Lastname"><b>Last Name:</b></label>
                    <input id="Last Name" type="text" name="lastname" onfocus="focusFunc(this.id)"
                        onblur="blurFunc(this.id)">
                    <p id="Last NameT" style="display: inline; margin-left: 30px;"></p><br />
                </div>
            </div>
            <label for="Phone Number"><b>Phone Number:</b></label>
            <input id="Phone Number" type="tel" pattern="[0-9]{3}[0-9]{3}[0-9]{4}" placeholder="(_ _ _-_ _ _-_ _ _ _)"
                name="phonenumber" onfocus="focusFunc(this.id)" onblur="blurFunc(this.id)">
            <p id="Phone NumberT" style="display: inline; margin-left: 30px;"></p><br />

            <label for="email"><b>Email:</b></label>
            <input id="Email" type="text" name="email" onfocus="focusFunc(this.id)" onblur="blurFunc(this.id)">
            <p id="EmailT" style="display: inline; margin-left: 30px;"></p><br />

            <div class="address_wrapper">
                <div class="address">
                    <label for="Address"><b>Agent Position::</b></label>
                    <input id="Agent Position" type="text" name="agentposition" onfocus="focusFunc(this.id)"
                        onblur="blurFunc(this.id)">
                    <p id="Agent PositionT" style="display: inline; margin-left: 30px;"></p><br />
                </div>
                <div class="city">
                    <label for="City"><b>AgencyId:</b></label>
                    <input id="AgencyId" type="text" name="AgencyId" onfocus="focusFunc(this.id)" onblur="blurFunc(this.id)">
                    <p id="AgencyIdT" style="display: inline; margin-left: 30px;"></p><br />
                </div>
            </div>
            
            <label for="userID"><b>userID:</b></label>
            <input id="userID" type="text" name="userID" onfocus="focusFunc(this.id)" onblur="blurFunc(this.id)">
            <p id="userIDT" style="display: inline; margin-left: 30px;"></p><br />

            <label for="Password"><b>Password:</b></label>
            <input id="Password" type="Password" name="Password" onfocus="focusFunc(this.id)" onblur="blurFunc(this.id)">
            <p id="PasswordT" style="display: inline; margin-left: 30px;"></p><br />
            <hr>
            <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
            <div class="submit_wrapper">
                <button id="register" name="submit"  type="submit" class="registerbtn" onclick="return validation()">Register</button>
                <button type="reset" class="resetbtn" value="Start Over"
                    onClick="return confirm('Do you want to submit the form?')">Reset</button>
            </div>
        </div>
        
        <div>
            <?php
                //include_once("Agent_form.php");
            ?>
        </div>
        <div id="error" style="color:blue"> </div>

        <div class="container signin">
            <p>Already have an account? <a href="#">Sign in</a>.</p>
        </div>
    </form>

   
</body>

</html>