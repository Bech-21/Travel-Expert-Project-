var imgArray = ['images/backpacker.jpg', 'images/elephant.jpg', 'images/Giraff.jpg', 'images/Zebra.jpg', 'images/africa.jpg', 'images/Zebra.jpg', 'images/giraffe2.jpg', 'images/antelope.jpg', 'images/safari.jpg'];
var imgDescArr = ['waterfall', 'elephant', 'giraffe', 'Zebra', 'africa wild', 'zebra', 'giraffe', 'antelope', 'lion'];
linkArr = ["https://www.youtube.com/", "https://www.bing.com/", "https://www.yahoo.com/", "https://www.maxifoot.com/", "https://www.sait.ca/", "https://www.ucalgary.com/", "https://www.hotmail.com/", "https://www.facebook.com/", "https://www.gmail.com/"]
document.write("<table id='table1'>");
for (i = 0; i < imgArray.length; i++) {
    document.write("<tr>");
    document.write("<td><img id=" + i + " src=" + imgArray[i] +
        " width= 60 height=60) /></td>");
    document.write("</tr>");

    var imgDesc = imgDescArr[i];

    document.getElementById(i).addEventListener("mouseover", function () {
        showDesc(this.id);
    });

    document.getElementById(i).addEventListener("mouseout", function () {
        hideDesc();
    });
    document.getElementById(i).addEventListener("click", function () {
        handleWindow(this.id);
    });

}
document.write("</table>");
document.write("<span id = 'output'></span>");

function showDesc(imgId) {
    var imgDesc = imgDescArr[imgId];
    //alert(imgDesc);
    var spanOut = document.getElementById("output");
    spanOut.className = "highlight";
    spanOut.style.visibility = "Visible";
    spanOut.innerHTML = imgDesc;

}
function hideDesc() {
    //document.getElementById(desc).innerHTML = imgdesc;
    document.getElementById("output").style.visibility = "hidden";
}
function handleWindow(imageId) {
    var LinkDesc = linkArr[imageId]
    if (imageId == "0")
        newWindow = window.open(LinkDesc); //open a window
    else if (imageId == "1")
        newWindow = window.open(LinkDesc);
    else if (imageId == "2")
        newWindow = window.open(LinkDesc);
    else if (imageId == "3")
        newWindow = window.open(LinkDesc);
    else if (imageId == "4")
        newWindow = window.open(LinkDesc);
    else if (imageId == "5")
        newWindow = window.open(LinkDesc);

    setTimeout(function () { newWindow.close(); }, 3000); //close window after 3 seconds
}