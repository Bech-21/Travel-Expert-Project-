<?php



 $links = array("https://safariguideafrica.com/product/best-of-southern-africa/"=>"Safari Guide", "https://www.travelocity.ca/?langid=4105"=>"Travelocity", "http://www.safariguides.com/"=>"Safari Guides");
 

 

?>