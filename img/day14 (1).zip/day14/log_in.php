<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register</title>
    <!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">
    <script text="text/javascript" src="script.js"></script>
</head>


<body>
<?php
include_once("header.php");

?>

    <form method="POST" action="loginValidatinForm.php">
        <div class="container">
            <h2 class="register">LOGIN</h2>
            <p>Please fill in this form to create an account.</p>
            <hr>
            <label for="userID"><b>userID:</b></label>
            <input id="userID" type="text" name="userID" onfocus="focusFunc(this.id)" onblur="blurFunc(this.id)">
            <p id="userIDT" style="display: inline; margin-left: 30px;"></p><br />         
           
           <label for="Password"><b>Password:</b></label>
            <input id="Password" type="Password" name="Password" onfocus="focusFunc(this.id)" onblur="blurFunc(this.id)">
            <p id="PasswordT" style="display: inline; margin-left: 30px;"></p><br />
          
               
            <hr>           
            <div class="submit_wrapper">
                <button id="login" name="login"  type="submit" class="registerbtn" onclick="return validation()">LOG IN</button>
                <button type="reset" class="resetbtn" value="Start Over"
                    onClick="return confirm('Do you want to submit the form?')">Reset</button>
            </div>
        </div>
        
 
        <div id="error" style="color:blue"> </div>

        
    </form>

   
</body>

</html>