<?php

   function insert($tableName,$array){
      $dbServername="localhost";
      $dbUsername="root";
      $dbPassword="";
      $dbName="travelexperts";
      $link = mysqli_connect( $dbServername,$dbUsername, $dbPassword,$dbName) or die("Connection Error: " . mysqli_connect_error());
      
      $columns = array_keys($array);
      $columns = implode(",",$columns);
      $values = array_values($array);
      $values = implode('","',array_values($array));
      
     
      $sql = sprintf('INSERT INTO %s'.'(%s) VALUES ("%s")',$tableName,$columns,$values);
      $result = mysqli_query($link, $sql) or die("SQL Error");
        
         if ($result)
         {
            print("Agent inserted");
         }
         else
         {
            print("Agent not inserted");
         }
         mysqli_close($link);
}

function connectDatabase()
   {
     $conn = @new mysqli("localhost", "root", "", "travelexperts");
     if ($conn->connect_errno)
     {
       die("Error: ". $conn->connect_error);
     }
     return $conn;
   }
?>
