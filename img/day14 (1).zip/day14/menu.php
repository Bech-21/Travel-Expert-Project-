<section class="grid-wrapper">

        <div class="box zone"> <img src="images/backpacker.jpg" alt="Sorry Image is not available"></div>
        <div class="box zone"><img src="images/elephant.jpg" alt="Sorry Image is not available"></div>
        <div class="box zone"><img src=" images/Giraff.jpg" alt="Sorry Image is not available"></div>
        <div class="box zone"><img src=" images/Zebra.jpg" alt="Sorry Image is not available"> </div>
        <div class="box zone"><img src=" images/africa.jpg" alt="Sorry Image is not available"></div>
        <div class="box zone"><img src="images/Zebra.jpg" alt="Sorry Image is not available"> </div>
        <div class="box zone"><img src="images/giraffe2.jpg" alt="Sorry Image is not available"> </div>
        <div class="box zone"><img src="images/antelope.jpg" alt="Sorry Image is not available"> </div>
        <div class="box zone"><img src="images/safari.jpg" alt="Sorry Image is not available"> </div>
        <div class="box zone"><img src="images/panther.jpg" alt="Sorry Image is not available"> </div>
        <div class="box zone"><img src="images/masai.jpg" alt="Sorry Image is not available"> </div>
        <div class="box zone"><img src="images/rhino.jpg" alt="Sorry Image is not available"> </div>

        <!-- <div class= "box zone"> </div> --- Extra div for additional pic-->
    </section>
    <script text="text/javascript" src="script_index.js"></script>