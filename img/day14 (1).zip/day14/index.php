<!--Author:Bachir Mahomad
    Date:28/06/2019
    Functionality:Version 4 adding styling
--><?php

    include_once("header.php"); 
   
    include_once("menu.php");
    include_once("footer.php");
    ?>


    
    <!-- 
    f.	At the bottom of the index.html page display a copyright message with a copyright symbol. -->
    
    
</body>

</html>