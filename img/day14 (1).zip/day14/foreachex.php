<html>
	<head>
		 <title>Foreach Example</title>
	</head>
	<body>
		 <?php
			/* The following code will create three links using <a> */
			
            echo "<a href=index.php>Index</a><br>";

			$links = array("page1.php","page2.php","page3.php","page4.php","page5.php","page6.php");
			echo "<table style ='border:1px solid black'>";
			echo "<tr><th style ='border:1px solid black>Page Number </th><th>Page URL</th></tr>";
			$i=1;
			foreach($links as $link)
			{
			echo "<tr>";
			echo "<td style ='border:1px solid black'>".$i."</td>";	
			echo "<td style ='border:1px solid black'><a href=\"http://$link\">$link</a></td>";					
			echo "</tr>";
			$i++;
			}			
			echo"</table>";

			// $links = array("mysql.com","php.net","www.apache.org")
			// for($i=0;$i<=count($links);$i++) {
			// echo "<tr>";
			// echo "<td>".$i."</td>";	
			// echo"<td><img src='"+imgArr[i]+"'/></td>";		
			
			// document.write("</tr>");
				
			// }
		?> 
	</body>
</html>
