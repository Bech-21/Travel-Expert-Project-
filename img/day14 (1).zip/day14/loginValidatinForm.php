<?php
session_start();
include("function.php");
if (isset($_POST['login'])){
    
    $user =  $_POST['userID'];    
    $Password =  md5(trim($_POST['Password'])) ;    
            
    echo $user;
    echo $Password;
    $conn = connectDatabase();
    $sql = "SELECT password from agents WHERE UserID=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $stmt->bind_result($password);
    $stmt->fetch();
    if ($password == $Password)
    {
      //login is okay, set session var
      $_SESSION["loggedin"] = $user;
      header("Location: index.php");
    }
    else {
      $_SESSION["message"] = "UserId or Password is incorrect";
      header("Location:log_in.php");
    }

 
   } else {
    
    header("Location:log_in.php");
   }
   
   ?>