<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register</title>
    <!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">

</head>


<body>
<?php
include_once("header.php");

?>

    <form method="POST" action="submit_wrapper.php">
        <div class="container">
            <h2 class="register">Register</h2>
            <p>Please fill in this form to create an account.</p>
            <hr>
            <div class="name_wrapper">
                <div class="firstname">
                    <label for="firstname"><b>First Name:</b></label>
                    <input id="First Name" type="text" name="firstname" onfocus="focusFunc(this.id)"
                        onblur="blurFunc(this.id)">
                    <p id="First NameT" style="display: inline; margin-left: 30px;"></p><br />
                </div>
                <div class="lastname">
                    <label for="Lastname"><b>Last Name:</b></label>
                    <input id="Last Name" type="text" name="lastname" onfocus="focusFunc(this.id)"
                        onblur="blurFunc(this.id)">
                    <p id="Last NameT" style="display: inline; margin-left: 30px;"></p><br />
                </div>
            </div>

            <div class="address_wrapper">
                <div class="address">
                    <label for="Address"><b>Address:</b></label>
                    <input id="Address" type="text" name="address" onfocus="focusFunc(this.id)"
                        onblur="blurFunc(this.id)">
                    <p id="AddressT" style="display: inline; margin-left: 30px;"></p><br />
                </div>
                <div class="city">
                    <label for="City"><b>City:</b></label>
                    <input id="City" type="text" name="city" onfocus="focusFunc(this.id)" onblur="blurFunc(this.id)">
                    <p id="CityT" style="display: inline; margin-left: 30px;"></p><br />
                </div>
            </div>
            <div class="province_wrapper">
                <div class="province">
                    <label for="Province"><b>Province:</b></label>
                    <input id="Province" type="text" name="Province" onfocus="focusFunc(this.id)"
                        onblur="blurFunc(this.id)">
                    <p id="ProvinceT" style="display: inline; margin-left: 30px;"></p><br />

                </div>
                <div class="country">
                    <label for="Country"><b>Country:</b></label>
                    <input id="Country" type="text" name="Country" onfocus="focusFunc(this.id)"
                        onblur="blurFunc(this.id)">
                    <p id="CountryT" style="display: inline; margin-left: 30px;"></p><br />
                </div>
                <div class="postal">
                    <label for="Postal"><b>Postal Code:</b></label>
                    <input id="Postal Code" type="text" name="Postal Code" onfocus="focusFunc(this.id)"
                        onblur="blurFunc(this.id)" pattern="[A-Za-z]\d[A-Za-z] ?\d[A-Za-z]\d">
                    <p id="Postal CodeT" style="display: inline; margin-left: 30px;"></p><br />
                </div>
            </div>
            <label for="Phone Number"><b>Phone Number:</b></label>
            <input id="Phone Number" type="tel" pattern="[0-9]{3}[0-9]{3}[0-9]{4}" placeholder="(_ _ _-_ _ _-_ _ _ _)"
                name="Phone Number" onfocus="focusFunc(this.id)" onblur="blurFunc(this.id)">
            <p id="Phone NumberT" style="display: inline; margin-left: 30px;"></p><br />


            <label for="email"><b>Email:</b></label>
            <input id="Email" type="text" name="email" onfocus="focusFunc(this.id)" onblur="blurFunc(this.id)">
            <p id="EmailT" style="display: inline; margin-left: 30px;"></p><br />

            <label for="psw"><b>Password:</b></label>
            <input id="Password" type="password" name="psw" onfocus="focusFunc(this.id)" onblur="blurFunc(this.id)">
            <p id="PasswordT" style="display: inline; margin-left: 30px;"></p><br />

            <label for="psw-repeat"><b>Repeat Password:</b></label>
            <input id="Password Repeat" type="password" name="psw-repeat" onfocus="focusFunc(this.id)"
                onblur="blurFunc(this.id)">
            <p id="Password RepeatT" style="display: inline; margin-left: 30px;"></p><br />
            <hr>
            <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
            <div class="submit_wrapper">
                <button id="register" type="submit" class="registerbtn" onclick="return validation()">Register</button>
                <button type="reset" class="resetbtn" value="Start Over"
                    onClick="return confirm('Do you want to submit the form?')">Reset</button>
            </div>
        </div>
        <div id="error" style="color:blue"> </div>

        <div class="container signin">
            <p>Already have an account? <a href="#">Sign in</a>.</p>
        </div>
    </form>

    <script text="text/javascript" src="script.js"></script>
</body>

</html>