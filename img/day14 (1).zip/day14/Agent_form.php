<?php
if (isset($_POST['submit'])){
   
    $agentArr=  array('AgtFirstName' =>$_POST['firstname'],
                  'AgtMiddleInitial'=>$_POST['middlename'],
                  'AgtLastName'=>$_POST['lastname'],
                  'AgtBusPhone'=>$_POST['phonenumber'],
                  'AgtEmail'=>$_POST['email'],
                  'AgtPosition'=>$_POST['agentposition'],
                  'AgencyId'=>$_POST['AgencyId'],
                  'UserId'=>$_POST['userID'], 
                  'Password'=>md5(trim($_POST['Password'])) 
                 );
                 print_r($_POST);
   
    include_once("function.php");
    insert('agents',$agentArr);
    foreach($_POST as $key=>$val) 
   {
	  $$key = $val;
   }

   $filename = "data.txt";
   $filepointer = fopen($filename,"a+");
   if(fwrite($filepointer,"firstname: $firstname\nmiddlename: $middlename\nlastname: $lastname\nphonenumber: $phonenumber\nemail: $email\nagentposition: $agentposition\nAgencyId: $AgencyId\n\n")) 
   {
       
	   echo "<br>File written successfully";
   } 
   else 
   {
	  echo "File not written";
   }
   fclose($filepointer);
  //  To redirect form on a particular page
    
    //header("Location: http://localhost/Agent_register.php");
    //die();
    
    
}else{
 
    ECHO "INSERTED DATA FAIL";
 }
header("refresh: 3; url = Agent_register.php");
// header("refresh: 3; url:shttp:\\localhost\\travel_agency\\day12\\day12\\day11\\Agent_register.php");
?>